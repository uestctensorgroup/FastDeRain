This is a demo to test the performance of UGSM single image rain removal method [1] which is designed by L.J. Deng et al.

@copyright Liang-Jian Deng(UESTC)

email: liangjian.deng@uestc.edu.cn  or liangjian.deng@gmail.com

Code page: http://www.escience.cn/people/dengliangjian/codes.html
=====================================================
You can directly run the following three demo to test our method, which:

demo_exp2_synimage ---------- test demo for some synthetic examples of Fig. 6

demo_exp3_realimage ---------- test demo for one real example of Fig. 1

======================================================

If you use the code, please cite the two references:

[1] Liang-Jian Deng, Ting-Zhu Huang, Xi-Le Zhao, Tai-Xiang Jiang, A directional global sparse model for single image rain removal, Applied Mathematical Modelling, 2018. DOI:doi.org/10.1016/j.apm.2018.03.001

[2] Tai-Xiang Jiang, Ting-Zhu Huang, Xi-Le Zhao, Liang-Jian Deng, Yao Wang, A novel tensor-based video rain streaks removal approach via utilizing discriminatively intrinsic priors, IEEE Conference on Computer Vision and Pattern Recognition (CVPR), Honolulu, Hawaii, USA, 2017.

========================================================
You can visit my homepage for other papers:
http://www.escience.cn/people/dengliangjian/index.html