function [s,ii]=ugsm(I,opts)
%% ---the right version!!!!
%---date: 2016-5-10
%---------
if strcmp(opts.imgname, 'exp1.bmp')
    opts.lamda1=0.01;% 0.01
    opts.lamda2=1;% 1
    opts.beta1=100;  % 100
    opts.beta2=100;% 100
    opts.beta3=100;% 100
    opts.beta4=100;% 100
end

[m,n]=size(I);
C=getC(I);
D1=defDD1t;  %y-direction finite function
D2=defDD2t;  %x-direction finite function
Dt=defDDt;

%%%%--------------initialization----------%%%%
f=I;
s=zeros(m,n);  
p1=zeros(n,m);  %%!!!
p2=p1;
p3=p1;
lamda1=opts.lamda1;
lamda2=opts.lamda2;
beta1=opts.beta1;
beta2=opts.beta2;
beta3=opts.beta3;
tol=opts.tol;
maxitr=opts.maxitr;
%Denom=beta1*C.eigsD1tD1+beta2*eyes(m,n)+beta3*C.eigsD2tD2;  
Denom=beta3*C.eigsD1tD1+beta2*ones(m,n)+beta1*C.eigsD2tD2;%% eyes(m,n)

%%%%--------------finite diff-------------%%%%
D2s=D2(s);         %   d_x(s)
D1s=D1(f-s);       %   d_y(f-s)
%%%%--------------Main loop---------------%%%%
ii=0;
relchg=1;
y=zeros(m,n);
while relchg> tol && ii<maxitr 
    V1=D2s+p1'/beta1;
    V2=D1s+p3'/beta3;
    %%%%----------x-subproblem------------%%%%
    x=sign(V1).*max(0,abs(V1)-1/beta1);
    %%%%----------z-subproblem------------%%%%
    z=sign(V2).*max(0,abs(V2)-lamda2/beta3);
    %%%%----------y-subproblem------------%%%%
    %%%%----------group sparse l_{2,1}----%%%%
%     for i=1:n
%         r=s(:,i)+p2(i,:)'/beta2;
%         y(:,i)=r.*max(norm(r)-lamda1/beta2,0)/(norm(r)+eps);
%     end
%         %%%%-------global sparse l_1--------%%%%%
    V3=s+p2'/beta2;
    y = sign(V3).*max(0,abs(V3)-lamda1/beta2);
     %%%%------global sparse l_0--------%%%%%
%      V3=s+p2'/beta2;
%      jj=find(abs(V3)>=sqrt(2*lamda1/beta2));
%      y(jj)=V3(jj);
 %%%%----------s-subproblem------------%%%%
    sp=s;
    temp1=beta3*D1(f)-beta3*z+p3';
    temp2=beta2*y-p2';
    temp3=beta1*x-p1';
    s1=Dt(temp1,temp3)+temp2;
    s2=fft2(s1)./Denom;
    s=real(ifft2(s2));
    s(s<0) = 0;
    s(s>1) = 1;
    u1=f-s;
    u2=f-sp;
    relchg=norm(u1-u2,'fro')/norm(u1,'fro');
    %Normrel=norm(u1-rt,'fro')/norm(rt,'fro');
    %Error(ii+1)  =  Normrel;
    ii=ii+1;
    %%%%------------finit diff------------%%%%
    D2s=D2(s);
    D1s=D1(f-s);
    %%%%------------update p--------------%%%%
    p1=p1+1.618*beta1*(D2s-x)';
    p2=p2+1.618*beta2*(s-y)';
    p3=p3+1.618*beta3*(D1s-z)';
end
%%%%--------------Subfunction-------------%%%%
function C=getC(I)
sizeI=size(I);
C.eigsD1tD1=abs(psf2otf([1,-1],sizeI)).^2;
C.eigsD2tD2=abs(psf2otf([1;-1],sizeI)).^2;
end
%%%%--------------Subfunction-------------%%%%
function D1=defDD1t
D1=@(U)ForwardD1(U);
end

function D2=defDD2t
D2=@(U)ForwardD2(U);
end

function Dt=defDDt
Dt= @(X,Y) Dive(X,Y);
end

function Dux=ForwardD1(U)
Dux=[diff(U,1,2),U(:,1)-U(:,end)];
end

function Duy=ForwardD2(U)
Duy=[diff(U,1,1);U(1,:)-U(end,:)];
end

function DtXY = Dive(X,Y)
DtXY = [X(:,end) - X(:, 1), -diff(X,1,2)];
DtXY = DtXY + [Y(end,:) - Y(1, :); -diff(Y,1,1)];
end
end