% A demo for synthetic images of [1] 
% L.J.Deng(UESTC)
%=======================
% Please cite:

% [1] Liang-Jian Deng, Ting-Zhu Huang, Xi-Le Zhao, 
% Tai-Xiang Jiang, A directional global sparse model for 
% single image rain removal, Applied Mathematical Modelling,
% 2018. DOI:doi.org/10.1016/j.apm.2018.03.001

% [2] Tai-Xiang Jiang, Ting-Zhu Huang, Xi-Le Zhao, 
% Liang-Jian Deng, Yao Wang, A novel tensor-based video rain 
% streaks removal approach via utilizing discriminatively 
% intrinsic priors, IEEE Conference on Computer Vision and 
% Pattern Recognition (CVPR), Honolulu, Hawaii, USA, 2017.

%% ====================
clear all; close all
addpath(genpath('.'));
%% ====================
[filename, filepath, FilterIndex ] = uigetfile('Exp2/*.*','Read image');
RainI    =  double(imread(fullfile(filepath,filename)))/255;
opts.imgname = filename;
I = rgb2ycbcr(RainI);
a1=I(:,:,1);
a2=I(:,:,2);
a3=I(:,:,3);
opts.lamda1=0.08; opts.lamda2=0.95;
opts.beta1=200;  opts.beta2=opts.beta1; opts.beta3=opts.beta1;
opts.beta4=opts.beta1; opts.tol=1e-3; opts.maxitr=400;
tic
[s1,ii]=ugsm(a1,opts);
toc
derain(:,:,1) = a1 - s1;
derain(:,:,2) = a2;
derain(:,:,3) = a3;

Dera_final = ycbcr2rgb(uint8(255*derain));
%===========presentation====================%
Str1 = strcat(filename, '_cvpr16.png');
Rainother = double(imread(Str1))/255; 
Str2 = strcat(filename, '_true.bmp');
Rain_true = double(imread(Str2))/255; 
Str3 = strcat(filename, '_iccv15.mat');

load (Str3); 
Rain_15iccv = im_derain;

figure,
subplot(2,2,1); imshow(RainI,[]); title('rain')
subplot(2,2,2); imshow(Rain_15iccv,[]); title('iccv')
subplot(2,2,3); imshow(Rainother,[]); title('cvpr')
subplot(2,2,4); imshow(Dera_final,[]); title('our')

%===========quantitative showing====================%
rain_true = rgb2ycbcr(Rain_true);% true
rt = rain_true(:,:,1);
rainother= rgb2ycbcr(Rainother); % cvpr2016
ro = rainother(:,:,1);
rain15iccv= rgb2ycbcr(Rain_15iccv); % cvpr2016
r15iccv = rain15iccv(:,:,1);
rour = derain(:,:,1);
%% ---ssim on background-----%
ssim_16cvpr = ssim(255*rt, 255*ro);
ssim_15iccv  = ssim(255*rt, 255*r15iccv);
ssim_our       = ssim(255*rt, 255*rour);
%% ---psnr on background-----%
psnr_iccv      = psnr(rt, r15iccv);
psnr_16cvpr = psnr(rt, ro);
psnr_our      = psnr(rt, rour);

%% ========display results==========%%
disp('=========SSIM=========');
disp(['  ','  ','  ','  ','  ','  ','  ','15ICCV','  ','  ','  ','16CVPR', '  ', '  ','Proposed', ' ', ' '])
disp(['SSIM',' ','  ','  ',num2str(ssim_15iccv),' ','  ', '  ',num2str(ssim_16cvpr),' ','  ', '  ',num2str(ssim_our)]);

